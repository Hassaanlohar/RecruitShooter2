package com.recruit.shooter;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private WebView web;

    // The multiplayer server runs inside the app: the phone that taps "Host" IS the server.
    private GameServer server;
    private volatile int serverPort = 0;
    private final CountDownLatch serverReady = new CountDownLatch(1);

    /** Seen by the game's JavaScript as window.RSApp */
    private class Bridge {
        @JavascriptInterface
        public int port() {
            try {
                serverReady.await(3, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            return serverPort; // 0 = server could not start
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        startServer();
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setUserAgentString(s.getUserAgentString() + " RecruitApp");
        web.setBackgroundColor(0xFF141A10);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "RSApp");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void startServer() {
        final GameServer srv = new GameServer();
        srv.setAddressProvider(new GameServer.AddressProvider() {
            @Override
            public List<String> addresses() {
                return findAddresses();
            }
        });
        server = srv;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    serverPort = srv.start(GameServer.DEFAULT_PORT);
                } catch (Exception e) {
                    serverPort = 0;
                } finally {
                    serverReady.countDown();
                }
            }
        }, "rs-server-start").start();
    }

    /** This phone's Wi-Fi / hotspot addresses: what the friends type into their game. */
    private List<String> findAddresses() {
        List<String> out = new ArrayList<String>();
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                    if (caps == null) continue;
                    if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                            && !caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) continue;
                    LinkProperties lp = cm.getLinkProperties(n);
                    if (lp == null) continue;
                    for (LinkAddress la : lp.getLinkAddresses()) {
                        InetAddress a = la.getAddress();
                        if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                            String ip = a.getHostAddress();
                            if (!out.contains(ip)) out.add(ip);
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        // also covers the phone's own hotspot, which Android does not list as a normal network
        for (String ip : GameServer.localAddresses()) {
            if (!out.contains(ip)) out.add(ip);
        }
        return out;
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    // Back button = same as Esc in the game (opens the pause menu / leaves the menu)
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("if(typeof escKey==='function')escKey()", null);
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() {
        if (server != null) server.stop();
        web.destroy();
        super.onDestroy();
    }
}
