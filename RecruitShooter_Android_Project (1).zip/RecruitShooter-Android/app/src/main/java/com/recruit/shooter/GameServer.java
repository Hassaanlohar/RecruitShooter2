package com.recruit.shooter;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Recruit Shooter multiplayer server, written in plain Java so it can run INSIDE the Android app
 * (the host's phone is the server). No libraries needed: it contains its own tiny WebSocket
 * (RFC 6455) implementation and JSON reader/writer.
 *
 * Protocol (same as the game's client in index.html):
 *   client -> server : create, join, st, fire, hit, die, resp, ping
 *   server -> client : joined, err, pj, pl, st, fire, hit, resp, kill, pong
 *
 * It can also run on a PC for testing:  java GameServer.java [port]
 */
public class GameServer {

    /** Lets the Android layer supply the phone's Wi-Fi / hotspot addresses. */
    public interface AddressProvider {
        List<String> addresses();
    }

    public static final int DEFAULT_PORT = 3000;
    static final int MAX_PLAYERS = 8;
    static final int MAX_ROOMS = 40;
    static final int MAX_FRAME = 64 * 1024;
    static final int QUEUE_LIMIT = 600;
    static final int MAX_MSGS_PER_SEC = 400;
    static final String WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    static final byte[] CLOSE_FRAME = frame(0x8, new byte[]{0x03, (byte) 0xE8});

    private final Map<String, Room> rooms = new HashMap<String, Room>();
    private final Set<Client> clients = Collections.newSetFromMap(new ConcurrentHashMap<Client, Boolean>());
    private final Random rnd = new Random();
    private volatile ServerSocket serverSocket;
    private volatile boolean running;
    private volatile int port;
    private volatile AddressProvider addressProvider;

    public void setAddressProvider(AddressProvider p) {
        addressProvider = p;
    }

    public int getPort() {
        return port;
    }

    /** Starts listening. Tries preferredPort, then the next 9 ports if it is taken. Returns the port used. */
    public synchronized int start(int preferredPort) throws IOException {
        if (running) return port;
        IOException last = null;
        for (int i = 0; i < 10; i++) {
            int p = preferredPort + i;
            ServerSocket ss = new ServerSocket();
            try {
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(p));
                serverSocket = ss;
                port = p;
                running = true;
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        acceptLoop();
                    }
                }, "rs-accept");
                t.setDaemon(true);
                t.start();
                return p;
            } catch (IOException e) {
                last = e;
                try {
                    ss.close();
                } catch (IOException ignore) {
                }
            }
        }
        throw last != null ? last : new IOException("No free port");
    }

    public synchronized void stop() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignore) {
        }
        for (Client c : new ArrayList<Client>(clients)) c.kick();
    }

    private void acceptLoop() {
        while (running) {
            try {
                Socket s = serverSocket.accept();
                if (clients.size() >= MAX_PLAYERS * MAX_ROOMS) {
                    try {
                        s.close();
                    } catch (IOException ignore) {
                    }
                    continue;
                }
                Client c = new Client(s);
                clients.add(c);
                Thread t = new Thread(c, "rs-client");
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                if (!running) break;
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }
    }

    // ------------------------------------------------------------------ rooms

    private static final class Room {
        final String pin;
        final boolean combat;
        final Map<Integer, Client> players = new LinkedHashMap<Integer, Client>();
        int nextId = 1;
        boolean dead;

        Room(String pin, boolean combat) {
            this.pin = pin;
            this.combat = combat;
        }

        /** Send to everyone except `except` (may be null). Caller must hold the room lock. */
        void broadcast(byte[] f, Client except) {
            for (Client c : players.values()) {
                if (c != except) c.sendFrame(f);
            }
        }

        void broadcastLocked(byte[] f, Client except) {
            synchronized (this) {
                broadcast(f, except);
            }
        }
    }

    private boolean createRoom(Client c, boolean combat) {
        Room r;
        synchronized (rooms) {
            if (rooms.size() >= MAX_ROOMS) {
                c.err("The server is full right now. Try again in a moment.");
                return false;
            }
            String pin = null;
            for (int i = 0; i < 300; i++) {
                String p = String.format(Locale.US, "%04d", rnd.nextInt(10000));
                if (!rooms.containsKey(p)) {
                    pin = p;
                    break;
                }
            }
            if (pin == null) {
                c.err("Could not make a PIN. Try again.");
                return false;
            }
            r = new Room(pin, combat);
            rooms.put(pin, r);
        }
        return enter(c, r, true);
    }

    private boolean joinRoom(Client c, String pin) {
        Room r;
        synchronized (rooms) {
            r = pin == null ? null : rooms.get(pin);
        }
        if (r == null) {
            c.err("No room with that PIN. Check the number with the host.");
            return false;
        }
        return enter(c, r, false);
    }

    private boolean enter(Client c, Room r, boolean host) {
        List<String> urls = host ? urlList() : new ArrayList<String>();
        synchronized (r) {
            if (r.dead) {
                c.err("That room just closed. Ask the host for a new PIN.");
                return false;
            }
            if (r.players.size() >= MAX_PLAYERS) {
                c.err("That room is full (" + MAX_PLAYERS + " players).");
                return false;
            }
            c.id = r.nextId++;
            c.room = r;
            c.host = host;
            c.kills = 0;
            c.deaths = 0;
            c.isDead = false;
            r.players.put(c.id, c);

            List<Object> plist = new ArrayList<Object>();
            for (Client p : r.players.values()) plist.add(p.info());
            Map<String, Object> joined = new LinkedHashMap<String, Object>();
            joined.put("t", "joined");
            joined.put("id", c.id);
            joined.put("pin", r.pin);
            joined.put("combat", r.combat);
            joined.put("urls", new ArrayList<Object>(urls));
            joined.put("host", host);
            joined.put("players", plist);
            c.sendFrame(textFrame(Json.write(joined)));

            Map<String, Object> pj = new LinkedHashMap<String, Object>();
            pj.put("t", "pj");
            pj.put("p", c.info());
            r.broadcast(textFrame(Json.write(pj)), c);
        }
        return true;
    }

    // ------------------------------------------------------------------ one connected phone

    private final class Client implements Runnable {
        final Socket sock;
        InputStream in;
        OutputStream out;
        final LinkedBlockingQueue<byte[]> outQ = new LinkedBlockingQueue<byte[]>(QUEUE_LIMIT);
        final AtomicBoolean closed = new AtomicBoolean(false);
        volatile boolean open = true;
        volatile boolean writerStarted = false;

        volatile Room room;
        int id;
        String name = "Recruit";
        Map<String, Object> look = new LinkedHashMap<String, Object>();
        int kills, deaths;
        boolean isDead, host;
        long winStart;
        int winCount;

        Client(Socket s) {
            this.sock = s;
        }

        @Override
        public void run() {
            try {
                sock.setTcpNoDelay(true);
                sock.setSoTimeout(8000);
                in = new BufferedInputStream(sock.getInputStream(), 4096);
                out = sock.getOutputStream();
                if (!handshake()) return;
                writerStarted = true;
                Thread w = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        writerLoop();
                    }
                }, "rs-writer");
                w.setDaemon(true);
                w.start();

                String first = readText();
                if (first == null || !handleFirst(first)) return;
                sock.setSoTimeout(60000);
                while (open) {
                    String m = readText();
                    if (m == null) break;
                    if (!allow()) continue;
                    handle(m);
                }
            } catch (IOException e) {
                // phone went away or sent garbage - just drop it
            } catch (RuntimeException e) {
                // a bad message must never take the server down
            } finally {
                shutdown();
            }
        }

        // ---- HTTP upgrade

        private boolean handshake() throws IOException {
            StringBuilder sb = new StringBuilder();
            int b;
            while ((b = in.read()) >= 0) {
                sb.append((char) b);
                int n = sb.length();
                if (n > 8192) return false;
                if (n >= 4 && sb.charAt(n - 4) == '\r' && sb.charAt(n - 3) == '\n'
                        && sb.charAt(n - 2) == '\r' && sb.charAt(n - 1) == '\n') break;
            }
            if (b < 0) return false;
            String[] lines = sb.toString().split("\r\n");
            Map<String, String> h = new HashMap<String, String>();
            for (int i = 1; i < lines.length; i++) {
                int c = lines[i].indexOf(':');
                if (c > 0) h.put(lines[i].substring(0, c).trim().toLowerCase(Locale.US), lines[i].substring(c + 1).trim());
            }
            String key = h.get("sec-websocket-key");
            String up = h.get("upgrade");
            if (key == null || up == null || !up.toLowerCase(Locale.US).contains("websocket")) {
                httpInfo();
                return false;
            }
            byte[] sha;
            try {
                sha = MessageDigest.getInstance("SHA-1").digest((key + WS_GUID).getBytes(StandardCharsets.US_ASCII));
            } catch (java.security.NoSuchAlgorithmException e) {
                return false;
            }
            String resp = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                    + "Sec-WebSocket-Accept: " + base64(sha) + "\r\n\r\n";
            out.write(resp.getBytes(StandardCharsets.US_ASCII));
            out.flush();
            return true;
        }

        /** Plain browser visit (http://ip:3000) - handy to test that the phones can see each other. */
        private void httpInfo() throws IOException {
            int rm;
            synchronized (rooms) {
                rm = rooms.size();
            }
            byte[] body = ("Recruit Shooter server is running.\nOpen rooms: " + rm + "\n").getBytes(StandardCharsets.UTF_8);
            String head = "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: "
                    + body.length + "\r\nConnection: close\r\n\r\n";
            out.write(head.getBytes(StandardCharsets.US_ASCII));
            out.write(body);
            out.flush();
        }

        // ---- WebSocket frames

        /** Returns the next text message, or null when the connection closed. */
        private String readText() throws IOException {
            ByteArrayOutputStream frag = null;
            boolean fragText = false;
            while (true) {
                int b0 = in.read();
                int b1 = in.read();
                if (b0 < 0 || b1 < 0) return null;
                boolean fin = (b0 & 0x80) != 0;
                int op = b0 & 0x0F;
                boolean masked = (b1 & 0x80) != 0;
                long len = b1 & 0x7F;
                if (len == 126) {
                    len = (readByte() << 8) | readByte();
                } else if (len == 127) {
                    len = 0;
                    for (int i = 0; i < 8; i++) len = (len << 8) | readByte();
                }
                if (len < 0 || len > MAX_FRAME) throw new IOException("frame too large");
                if (!masked) throw new IOException("client frames must be masked");
                byte[] mask = new byte[4];
                readFully(mask);
                byte[] data = new byte[(int) len];
                readFully(data);
                for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];

                if (op == 0x8) { // close
                    return null;
                } else if (op == 0x9) { // ping -> pong
                    sendFrame(frame(0xA, data));
                } else if (op == 0xA) { // pong
                    // ignore
                } else if (op == 0x1 || op == 0x2) {
                    if (fin) return op == 0x1 ? new String(data, StandardCharsets.UTF_8) : "";
                    frag = new ByteArrayOutputStream();
                    frag.write(data, 0, data.length);
                    fragText = op == 0x1;
                } else if (op == 0x0 && frag != null) {
                    frag.write(data, 0, data.length);
                    if (frag.size() > MAX_FRAME) throw new IOException("message too large");
                    if (fin) return fragText ? new String(frag.toByteArray(), StandardCharsets.UTF_8) : "";
                } else {
                    throw new IOException("bad opcode");
                }
            }
        }

        private int readByte() throws IOException {
            int b = in.read();
            if (b < 0) throw new IOException("eof");
            return b;
        }

        private void readFully(byte[] buf) throws IOException {
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) throw new IOException("eof");
                off += n;
            }
        }

        private void writerLoop() {
            try {
                while (true) {
                    byte[] f = outQ.poll(200, TimeUnit.MILLISECONDS);
                    if (f == null) {
                        if (!open) break;
                        continue;
                    }
                    out.write(f);
                    while ((f = outQ.poll()) != null) out.write(f);
                    out.flush();
                }
            } catch (Exception e) {
                // socket died
            } finally {
                closeSocket();
            }
        }

        void sendFrame(byte[] f) {
            if (!open) return;
            if (!outQ.offer(f)) kick(); // this phone cannot keep up - drop it instead of stalling everyone
        }

        void sendJson(Map<String, Object> m) {
            sendFrame(textFrame(Json.write(m)));
        }

        void err(String msg) {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("t", "err");
            m.put("msg", msg);
            sendJson(m);
        }

        void kick() {
            open = false;
            closeSocket();
        }

        void closeSocket() {
            try {
                sock.close();
            } catch (IOException ignore) {
            }
        }

        void shutdown() {
            if (!closed.compareAndSet(false, true)) return;
            leaveRoom();
            clients.remove(this);
            if (open && writerStarted) outQ.offer(CLOSE_FRAME);
            open = false;
            if (!writerStarted) closeSocket(); // writer thread closes it after flushing otherwise
        }

        void leaveRoom() {
            Room r = room;
            if (r == null) return;
            room = null;
            synchronized (r) {
                r.players.remove(id);
                r.broadcast(textFrame("{\"t\":\"pl\",\"id\":" + id + "}"), null);
                if (r.players.isEmpty()) {
                    r.dead = true;
                    synchronized (rooms) {
                        rooms.remove(r.pin);
                    }
                }
            }
        }

        boolean allow() {
            long now = System.currentTimeMillis();
            if (now - winStart > 1000) {
                winStart = now;
                winCount = 0;
            }
            return ++winCount <= MAX_MSGS_PER_SEC;
        }

        Map<String, Object> info() {
            Map<String, Object> p = new LinkedHashMap<String, Object>();
            p.put("id", id);
            p.put("name", name);
            p.put("look", look);
            p.put("kills", kills);
            p.put("deaths", deaths);
            return p;
        }

        /** Copy of the client's JSON with the server-assigned player id added (last key wins, so it can't be faked). */
        String withId(String raw) {
            String s = raw.trim();
            int end = s.lastIndexOf('}');
            if (end < 1) return null;
            return s.substring(0, end) + ",\"id\":" + id + "}";
        }

        // ---- game messages

        private boolean handleFirst(String text) {
            Map<String, Object> m = Json.parseObject(text);
            if (m == null) return false;
            String t = Json.str(m, "t");
            name = cleanName(Json.str(m, "name"));
            look = cleanLook(m.get("look"));
            if ("create".equals(t)) {
                return createRoom(this, !Boolean.FALSE.equals(m.get("combat")));
            } else if ("join".equals(t)) {
                return joinRoom(this, Json.str(m, "pin"));
            }
            return false;
        }

        private void handle(String text) {
            Room r = room;
            if (r == null) return;
            Map<String, Object> m = Json.parseObject(text);
            if (m == null) return;
            String t = Json.str(m, "t");
            if (t == null) return;

            if (t.equals("st")) {
                if (!(m.get("x") instanceof Number) || !(m.get("y") instanceof Number) || text.length() > 1024) return;
                String f = withId(text);
                if (f != null) r.broadcastLocked(textFrame(f), this);
            } else if (t.equals("fire")) {
                Object b = m.get("b");
                if (!(b instanceof List) || ((List<?>) b).isEmpty() || ((List<?>) b).size() > 16 || text.length() > 4096) return;
                String f = withId(text);
                if (f != null) r.broadcastLocked(textFrame(f), this);
            } else if (t.equals("hit")) {
                if (!r.combat || !(m.get("sh") instanceof Number) || !(m.get("k") instanceof Number)) return;
                String f = "{\"t\":\"hit\",\"sh\":" + Json.num(((Number) m.get("sh")).doubleValue())
                        + ",\"k\":" + Json.num(((Number) m.get("k")).doubleValue()) + "}";
                r.broadcastLocked(textFrame(f), this);
            } else if (t.equals("die")) {
                onDie(r, m);
            } else if (t.equals("resp")) {
                if (!(m.get("x") instanceof Number) || !(m.get("y") instanceof Number)) return;
                isDead = false;
                String f = "{\"t\":\"resp\",\"id\":" + id + ",\"x\":" + Json.num(((Number) m.get("x")).doubleValue())
                        + ",\"y\":" + Json.num(((Number) m.get("y")).doubleValue()) + "}";
                r.broadcastLocked(textFrame(f), this);
            } else if (t.equals("ping")) {
                Object n = m.get("n");
                String ns = n instanceof Number ? Json.num(((Number) n).doubleValue()) : "0";
                sendFrame(textFrame("{\"t\":\"pong\",\"n\":" + ns + "}"));
            }
        }

        private void onDie(Room r, Map<String, Object> m) {
            if (!r.combat) return;
            synchronized (r) {
                if (isDead) return;
                isDead = true;
                deaths++;
                int killerId = 0;
                Object k = m.get("killer");
                if (k instanceof Number) {
                    int kid = (int) ((Number) k).doubleValue();
                    Client killer = r.players.get(kid);
                    if (killer != null && killer != this) {
                        killer.kills++;
                        killerId = kid;
                    }
                }
                String w = Json.str(m, "w");
                if (w == null) w = "";
                if (w.length() > 40) w = w.substring(0, 40);
                List<Object> scores = new ArrayList<Object>();
                for (Client p : r.players.values()) {
                    List<Object> row = new ArrayList<Object>();
                    row.add(p.id);
                    row.add(p.kills);
                    row.add(p.deaths);
                    scores.add(row);
                }
                Map<String, Object> msg = new LinkedHashMap<String, Object>();
                msg.put("t", "kill");
                msg.put("killer", killerId);
                msg.put("victim", id);
                msg.put("w", w);
                msg.put("scores", scores);
                r.broadcast(textFrame(Json.write(msg)), null);
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private List<String> urlList() {
        List<String> ips = null;
        try {
            AddressProvider ap = addressProvider;
            if (ap != null) ips = ap.addresses();
        } catch (RuntimeException ignore) {
        }
        if (ips == null || ips.isEmpty()) ips = localAddresses();
        List<String> out = new ArrayList<String>();
        for (String ip : ips) {
            String u = port == DEFAULT_PORT ? ip : ip + ":" + port;
            if (!out.contains(u)) out.add(u);
        }
        return out;
    }

    /** IPv4 addresses of this device on Wi-Fi / hotspot / ethernet (what friends should type). */
    public static List<String> localAddresses() {
        List<String> pref = new ArrayList<String>();
        List<String> other = new ArrayList<String>();
        List<String> fallback = new ArrayList<String>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                try {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                } catch (SocketException e) {
                    continue;
                }
                String n = ni.getName().toLowerCase(Locale.US);
                boolean lan = n.startsWith("wlan") || n.startsWith("swlan") || n.startsWith("ap")
                        || n.startsWith("softap") || n.startsWith("eth") || n.startsWith("en");
                Enumeration<InetAddress> ea = ni.getInetAddresses();
                while (ea.hasMoreElements()) {
                    InetAddress a = ea.nextElement();
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || a.isLinkLocalAddress()) continue;
                    String ip = a.getHostAddress();
                    if (a.isSiteLocalAddress()) {
                        (lan ? pref : other).add(ip);
                    } else {
                        fallback.add(ip);
                    }
                }
            }
        } catch (Exception ignore) {
        }
        if (pref.isEmpty()) pref.addAll(other);
        if (pref.isEmpty()) pref.addAll(fallback);
        return pref;
    }

    static String cleanName(String s) {
        if (s == null) s = "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < 14; i++) {
            char ch = s.charAt(i);
            if (ch >= 32 && ch != 127) b.append(ch);
        }
        if (b.length() > 0 && Character.isHighSurrogate(b.charAt(b.length() - 1))) b.setLength(b.length() - 1);
        String r = b.toString().trim();
        if (r.isEmpty()) r = "Recruit" + (10 + new Random().nextInt(90));
        return r;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> cleanLook(Object o) {
        Map<String, Object> src = o instanceof Map ? (Map<String, Object>) o : null;
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        Object body = src == null ? null : src.get("body");
        String bs = body instanceof String ? (String) body : "m";
        if (!bs.matches("[A-Za-z0-9_\\-]{1,8}")) bs = "m";
        out.put("body", bs);
        out.put("face", smallInt(src, "face"));
        out.put("shoe", smallInt(src, "shoe"));
        return out;
    }

    private static int smallInt(Map<String, Object> m, String k) {
        Object v = m == null ? null : m.get(k);
        if (v instanceof Number) {
            int i = (int) Math.round(((Number) v).doubleValue());
            if (i >= 0 && i <= 999) return i;
        }
        return 0;
    }

    static byte[] textFrame(String s) {
        return frame(0x1, s.getBytes(StandardCharsets.UTF_8));
    }

    static byte[] frame(int op, byte[] p) {
        int n = p.length;
        byte[] f;
        if (n < 126) {
            f = new byte[2 + n];
            f[0] = (byte) (0x80 | op);
            f[1] = (byte) n;
            System.arraycopy(p, 0, f, 2, n);
        } else if (n < 65536) {
            f = new byte[4 + n];
            f[0] = (byte) (0x80 | op);
            f[1] = 126;
            f[2] = (byte) (n >> 8);
            f[3] = (byte) n;
            System.arraycopy(p, 0, f, 4, n);
        } else {
            f = new byte[10 + n];
            f[0] = (byte) (0x80 | op);
            f[1] = 127;
            long ln = n;
            for (int i = 0; i < 8; i++) f[2 + i] = (byte) (ln >>> (56 - 8 * i));
            System.arraycopy(p, 0, f, 10, n);
        }
        return f;
    }

    /** Base64 without java.util.Base64 (that class needs Android 8+; this app supports Android 7). */
    static String base64(byte[] d) {
        final String A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < d.length; i += 3) {
            int b0 = d[i] & 0xFF;
            int b1 = i + 1 < d.length ? d[i + 1] & 0xFF : 0;
            int b2 = i + 2 < d.length ? d[i + 2] & 0xFF : 0;
            sb.append(A.charAt(b0 >> 2));
            sb.append(A.charAt(((b0 & 3) << 4) | (b1 >> 4)));
            sb.append(i + 1 < d.length ? A.charAt(((b1 & 15) << 2) | (b2 >> 6)) : '=');
            sb.append(i + 2 < d.length ? A.charAt(b2 & 63) : '=');
        }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        int p = new GameServer().start(args.length > 0 ? Integer.parseInt(args[0]) : DEFAULT_PORT);
        System.out.println("Recruit Shooter server listening on port " + p + "  addresses: " + localAddresses());
        Thread.currentThread().join();
    }

    // ------------------------------------------------------------------ minimal JSON

    static final class Json {
        static String str(Map<String, Object> m, String k) {
            Object v = m.get(k);
            return v instanceof String ? (String) v : null;
        }

        static String num(double d) {
            if (Double.isNaN(d) || Double.isInfinite(d)) return "0";
            if (d == Math.rint(d) && Math.abs(d) < 1e15) return Long.toString((long) d);
            return BigDecimal.valueOf(d).toPlainString();
        }

        @SuppressWarnings("unchecked")
        static Map<String, Object> parseObject(String s) {
            try {
                Parser p = new Parser(s);
                p.ws();
                Object v = p.value(0);
                p.ws();
                if (p.i != s.length() || !(v instanceof Map)) return null;
                return (Map<String, Object>) v;
            } catch (RuntimeException e) {
                return null;
            }
        }

        static String write(Object o) {
            StringBuilder sb = new StringBuilder();
            write(sb, o);
            return sb.toString();
        }

        @SuppressWarnings("unchecked")
        static void write(StringBuilder sb, Object o) {
            if (o == null) {
                sb.append("null");
            } else if (o instanceof String) {
                quote(sb, (String) o);
            } else if (o instanceof Boolean || o instanceof Integer || o instanceof Long) {
                sb.append(o.toString());
            } else if (o instanceof Number) {
                sb.append(num(((Number) o).doubleValue()));
            } else if (o instanceof Map) {
                sb.append('{');
                boolean first = true;
                for (Map.Entry<String, Object> e : ((Map<String, Object>) o).entrySet()) {
                    if (!first) sb.append(',');
                    first = false;
                    quote(sb, e.getKey());
                    sb.append(':');
                    write(sb, e.getValue());
                }
                sb.append('}');
            } else if (o instanceof List) {
                sb.append('[');
                boolean first = true;
                for (Object v : (List<Object>) o) {
                    if (!first) sb.append(',');
                    first = false;
                    write(sb, v);
                }
                sb.append(']');
            } else {
                quote(sb, o.toString());
            }
        }

        static void quote(StringBuilder sb, String s) {
            sb.append('"');
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                switch (c) {
                    case '"':
                        sb.append("\\\"");
                        break;
                    case '\\':
                        sb.append("\\\\");
                        break;
                    case '\n':
                        sb.append("\\n");
                        break;
                    case '\r':
                        sb.append("\\r");
                        break;
                    case '\t':
                        sb.append("\\t");
                        break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                        else sb.append(c);
                }
            }
            sb.append('"');
        }

        private static final class Parser {
            final String s;
            int i = 0;

            Parser(String s) {
                this.s = s;
            }

            void ws() {
                while (i < s.length() && (s.charAt(i) == ' ' || s.charAt(i) == '\t' || s.charAt(i) == '\n' || s.charAt(i) == '\r')) i++;
            }

            Object value(int depth) {
                if (depth > 6) throw new IllegalStateException("too deep");
                ws();
                char c = s.charAt(i);
                if (c == '{') return object(depth);
                if (c == '[') return array(depth);
                if (c == '"') return string();
                if (s.startsWith("true", i)) {
                    i += 4;
                    return Boolean.TRUE;
                }
                if (s.startsWith("false", i)) {
                    i += 5;
                    return Boolean.FALSE;
                }
                if (s.startsWith("null", i)) {
                    i += 4;
                    return null;
                }
                return number();
            }

            Map<String, Object> object(int depth) {
                Map<String, Object> m = new LinkedHashMap<String, Object>();
                i++; // {
                ws();
                if (s.charAt(i) == '}') {
                    i++;
                    return m;
                }
                while (true) {
                    ws();
                    String k = string();
                    ws();
                    if (s.charAt(i++) != ':') throw new IllegalStateException("expected :");
                    m.put(k, value(depth + 1));
                    ws();
                    char c = s.charAt(i++);
                    if (c == '}') return m;
                    if (c != ',') throw new IllegalStateException("expected ,");
                }
            }

            List<Object> array(int depth) {
                List<Object> l = new ArrayList<Object>();
                i++; // [
                ws();
                if (s.charAt(i) == ']') {
                    i++;
                    return l;
                }
                while (true) {
                    l.add(value(depth + 1));
                    ws();
                    char c = s.charAt(i++);
                    if (c == ']') return l;
                    if (c != ',') throw new IllegalStateException("expected ,");
                }
            }

            String string() {
                if (s.charAt(i) != '"') throw new IllegalStateException("expected string");
                i++;
                StringBuilder b = new StringBuilder();
                while (true) {
                    char c = s.charAt(i++);
                    if (c == '"') return b.toString();
                    if (c != '\\') {
                        b.append(c);
                        continue;
                    }
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n':
                            b.append('\n');
                            break;
                        case 'r':
                            b.append('\r');
                            break;
                        case 't':
                            b.append('\t');
                            break;
                        case 'b':
                            b.append('\b');
                            break;
                        case 'f':
                            b.append('\f');
                            break;
                        case 'u':
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                            break;
                        default:
                            b.append(e); // \" \\ \/
                    }
                }
            }

            Double number() {
                int st = i;
                while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
                if (st == i) throw new IllegalStateException("bad value");
                double d = Double.parseDouble(s.substring(st, i));
                if (Double.isInfinite(d) || Double.isNaN(d)) throw new IllegalStateException("bad number");
                return d;
            }
        }
    }
}
