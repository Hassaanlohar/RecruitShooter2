RECRUIT SHOOTER - ANDROID APP PROJECT  (v1.1 - phone-hosted multiplayer)
=========================================================================
The app contains the game AND its own multiplayer server (GameServer.java, plain Java, no libraries).
No PC and no server.js needed any more: the phone that taps "Host" is the server.

HOW TO PLAY MULTIPLAYER
 1. Everyone installs the app and joins the SAME Wi-Fi (or one phone's hotspot).
 2. HOST: open the app -> enter a name -> tap Host. Nothing to type.
    The pause screen shows the 4-digit PIN and the host's address (e.g. 192.168.1.23).
 3. FRIENDS: open the app -> type the host's address in the server address box
    (only the first time - it is remembered) -> type the PIN -> tap Join with PIN.
 Keep the host's app open while playing (the server stops when the host closes the app).
 Up to 8 players per room. Test connection: open http://<host address>:3000 in a phone browser;
 it should say "Recruit Shooter server is running."

BUILD THE APK - easiest, no software to install (free GitHub account):
 1. Create a new private repository on github.com and upload everything in this folder
    (drag & drop the files/folders into the repo page; keep the .github folder).
 2. Open the repo's "Actions" tab -> "Build APK" -> wait ~3 minutes for the green tick.
    (If it did not start by itself: Actions -> Build APK -> "Run workflow".)
 3. Open the finished run -> "Artifacts" -> download RecruitShooter-apk -> unzip -> app-debug.apk
 4. Send app-debug.apk to your phone, tap it, allow "install unknown apps" when asked.

OR build with Android Studio: File -> Open this folder -> Build -> Build APK(s).

To change the game later: replace app/src/main/assets/index.html with a new Recruit_Shooter.html and rebuild.
(If you replace it, the game must still call the app's built-in server for Host - see the "RSApp" lines
 in connect() in index.html - otherwise Host will ask for a server address like before.)

FILES
 app/src/main/java/com/recruit/shooter/GameServer.java    the multiplayer server (WebSocket, rooms, PINs, kills)
 app/src/main/java/com/recruit/shooter/MainActivity.java  starts the server, wraps the game in a WebView
